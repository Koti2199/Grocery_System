<table align="center">
<tr>
    <td><img  width="700px"  height="60px" alt="Add Title Image" src="images\title.png" /></td> 
    <td><img  width="123px"  height="100px" alt="Add Title Image" src="images\logo1.png" /></td>
</tr>
</table>


<nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="background-color:;background-image:url(images/dark.png)">


  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">
          	        
	            <li class='nav-item'><a href='Home.php' class='nav-link' class='active'>Home</a></li>	        
	            <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" href="#">Logins<span class="caret"></span></a>
          <ul class="dropdown-menu">	        
	            <li class='nav-item'><a href='Admin_Login.php' class="dropdown-item" >Admin</a></li>	        
	            <li class='nav-item'><a href='Customer_Login.php' class="dropdown-item" >Customers</a></li>                
                </ul>
            </li> 
      </ul>
      
    </div>
  </div>
</nav>
