<!DOCTYPE html>
<html lang="en">
<head>
   <?php
	include 'groceryfiles/groceryfiles.php';
  ?>
  </style>
</head>
<body>

<?php 
include 'Admin_Home_Menu.php';
 ?>
<br>
<div class="jumbotron">
  <div class="container text-center">
    <h3><b>Welcome to Administration Portal</b></h3>  <br>
    <h4><b>One Place to Manage All the Stores</b></h4>  <br> 
    
    
  </div>
</div>
  
<div class="container-fluid bg-3 text-center">    
   <div class="row">
    <div class="col-sm-12">
      <img src="images/homex.png" class="img-responsive center" style="width:50%" alt="Image" ><br>
    </div>
   
   
   
   
  </div>
</div><br>



</body>
</html>
