<!DOCTYPE html>
<html lang="en">

<head>
  <?php
  include 'groceryfiles/groceryfiles.php';
  ?>
  </style>
</head>

<body>

  <?php
  include 'Home_Menu.php';
  ?>

  <div class="jumbotron">
    <div class="container text-center">
      <center>
        <h3><b>
            <p style="color: black;"> Welcome to Next Gen Grocery System</p>
          </b></h3>
      </center>


    </div>
  </div>

  <div class="container-fluid bg-3 text-center">
    <div class="row">
      <div class="col-sm-12">
        <img src="images/home.jpg" class="img-responsive center" style="width:70%" alt="Image">
      </div>

    </div>
  </div><br>

  <br><br>



</body>

</html>